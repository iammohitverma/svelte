<script>
</script>

<svelte:head>
	<title>Team</title>
	<meta name="description" content="Svelte demo app" />
</svelte:head>

<h1>Team</h1>