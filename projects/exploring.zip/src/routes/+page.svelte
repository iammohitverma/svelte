<script>
	import Nested from "../components/Nested.svelte";
</script>

<svelte:head>
	<title>Home</title>
	<meta name="description" content="Svelte demo app" />
</svelte:head>


<h1>Home</h1>