<script>
	// import './styles.css';
	import Header from './Header.svelte';
	import Footer from './Footer.svelte';
	import Allheaderlinks from './Allheaderlinks.svelte';
	// import Allfooterlinks from './Allfooterlinks.svelte';
</script>

<Allheaderlinks />

<div class="app">
	<Header />

	<main>
		<slot />
	</main>


	<!-- <Allfooterlinks /> -->
	<Footer />
</div>