<script>
	import { page } from '$app/stores';
	import logo from '$lib/assets/images/logo.png';

	// header toggle for mobile devices
	function navToggleFun() {
		let header = document.querySelector("header");
		header.classList.toggle("active");
	}
</script>

<header>

	<div class="container">
		<div class="inner">
			<a href="/" class="logo">
				<img src="{logo}" alt="">
			</a>

			<button class="navToggle" on:click={navToggleFun}>
				<i class="fa-solid fa-bars"></i>
			</button>

			<nav>
				<ul>
					<li aria-current={$page.url.pathname === '/' ? 'page' : undefined}>
						<a href="/">Home</a>
					</li>
					<li aria-current={$page.url.pathname === '/about' ? 'page' : undefined}>
						<a href="/about">About</a>
					</li>
					<li aria-current={$page.url.pathname.startsWith('/services') ? 'page' : undefined}>
						<a href="/services">Services</a>
					</li>
					<li aria-current={$page.url.pathname.startsWith('/team') ? 'page' : undefined}>
						<a href="/team">Team</a>
					</li>
					<li aria-current={$page.url.pathname.startsWith('/contact') ? 'page' : undefined}>
						<a href="/contact">Contact</a>
					</li>
				</ul>
			</nav>
		</div>
	</div>

</header>


