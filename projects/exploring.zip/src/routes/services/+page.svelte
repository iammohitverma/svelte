<script>
</script>

<svelte:head>
	<title>Serices</title>
	<meta name="description" content="Svelte demo app" />
</svelte:head>

<h1>Serices</h1>